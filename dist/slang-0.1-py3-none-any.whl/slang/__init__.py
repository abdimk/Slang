from .api import ChatLlama
from .api import ClaudeAI
from .api import Llama_Models


from .api import (
    Llama,QwenCoder,
    GeminiPro,GPT4,
    BlackboxAI,AskChat,NextChat,
    DuckChat,Chatx,Morphic
)


from .api import (
    model_type
)