"""
To Do 
allow the Model to acess your system settings and process
start from system date time to linux demons

"""
